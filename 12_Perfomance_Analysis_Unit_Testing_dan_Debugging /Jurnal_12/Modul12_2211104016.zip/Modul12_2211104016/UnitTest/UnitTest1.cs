﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Modul12_2211104016;

namespace UnitTest
{
    [TestClass]
    public class PangkatTests
    {
        [TestMethod]
        public void TestPangkatNormal()
        {
            Assert.AreEqual(8, Form1.CariNilaiPangkat(2, 3));
        }

        [TestMethod]
        public void TestPangkatB0()
        {
            Assert.AreEqual(1, Form1.CariNilaiPangkat(0, 0));
        }

        [TestMethod]
        public void TestPangkatBNegatif()
        {
            Assert.AreEqual(-1, Form1.CariNilaiPangkat(2, -2));
        }

        [TestMethod]
        public void TestPangkatOverLimit()
        {
            Assert.AreEqual(-2, Form1.CariNilaiPangkat(101, 2));
        }

        [TestMethod]
        public void TestPangkatOverflow()
        {
            Assert.AreEqual(-3, Form1.CariNilaiPangkat(100, 10));
        }
    }
}
