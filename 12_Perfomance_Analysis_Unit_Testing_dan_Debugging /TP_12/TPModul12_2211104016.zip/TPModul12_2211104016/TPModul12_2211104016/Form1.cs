﻿using System;
using System.Windows.Forms;

namespace TPModul12_2211104016
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string CariTandaBilangan(int a)
        {
            if (a < 0)
                return "Negatif";
            else if (a > 0)
                return "Positif";
            else
                return "Nol";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                label1.Text = "Masukkan angka terlebih dahulu";
                return;
            }

            try
            {
                int input = int.Parse(textBox1.Text);
                string hasil = CariTandaBilangan(input);
                label1.Text = $"Hasil: {hasil}";
            }
            catch (FormatException)
            {
                label1.Text = "Input tidak valid (harus angka)";
            }
            catch (Exception ex)
            {
                label1.Text = $"Terjadi error: {ex.Message}";
            }
        }

      
        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
