﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TPModul12_2211104016; 
namespace UnitTesting
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_CariTandaBilangan_Negatif()
        {
            var form = new Form1();   
            var result = form.CariTandaBilangan(-5);

            Assert.AreEqual("Negatif", result);
        }

        [TestMethod]
        public void Test_CariTandaBilangan_Positif()
        {
            var form = new Form1();

            var result = form.CariTandaBilangan(10);

            Assert.AreEqual("Positif", result);
        }

        [TestMethod]
        public void Test_CariTandaBilangan_Nol()
        {
            var form = new Form1();

            var result = form.CariTandaBilangan(0);

            Assert.AreEqual("Nol", result);
        }
    }
}
