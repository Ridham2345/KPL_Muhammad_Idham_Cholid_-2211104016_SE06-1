﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text;


namespace Jurnal15_2211104016
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsernameLogin.Text.Trim();
            string password = txtPasswordLogin.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username dan Password harus diisi.");
                return;
            }

            var user = UserService.FindUser(username);
            if (user == null)
            {
                MessageBox.Show("User tidak ditemukan.");
                return;
            }

            string hashedPassword = SecurityHelper.HashPassword(password);
            if (user.PasswordHash != hashedPassword)
            {
                MessageBox.Show("Password salah.");
                return;
            }

            MessageBox.Show("Login berhasil!");
            // Tambahkan logika redirect atau dashboard kalau perlu
        }

        private void btnToRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            RegisterForm regForm = new RegisterForm();
            regForm.Show();
        }

    }
}
