﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

public class User
{
    public string Username { get; set; }
    public string PasswordHash { get; set; }
}

public static class UserService
{
    private static string filePath = "users.json";

    public static List<User> LoadUsers()
    {
        if (!File.Exists(filePath))
            return new List<User>();

        string json = File.ReadAllText(filePath);
        return JsonConvert.DeserializeObject<List<User>>(json);
    }

    public static void SaveUsers(List<User> users)
    {
        string json = JsonConvert.SerializeObject(users, Formatting.Indented);
        File.WriteAllText(filePath, json);
    }

    public static void AddUser(User user)
    {
        var users = LoadUsers();
        users.Add(user);
        SaveUsers(users);
    }

    public static User FindUser(string username)
    {
        return LoadUsers().Find(u => u.Username == username);
    }
}
