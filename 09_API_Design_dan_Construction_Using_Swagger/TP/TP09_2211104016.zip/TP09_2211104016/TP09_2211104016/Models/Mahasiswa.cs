﻿namespace TP09_2211104016.Models
{
    public class Mahasiswa
    {
        public string? Nama { get; set; }
        public string? Nim { get; set; }
    }
}
