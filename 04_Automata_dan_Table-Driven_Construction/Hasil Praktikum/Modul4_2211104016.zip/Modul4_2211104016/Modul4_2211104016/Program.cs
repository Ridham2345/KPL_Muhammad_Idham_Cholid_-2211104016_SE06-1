﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modul4_2211104016
{
    public class Program
    {
        enum State { START, GAME, PAUSE, EXIT }

        public static void Main()
        {
            State state = State.START;
            string[] screenNames = { "START", "GAME", "PAUSE", "EXIT" };

            while (state != State.EXIT)
            {
                Console.WriteLine($"{screenNames[(int)state]} SCREEN");
                Console.Write("Enter Command: ");
                string command = Console.ReadLine()?.ToUpper(); // Convert input to uppercase for consistency

                switch (state)
                {
                    case State.START:
                        if (command == "ENTER")
                            state = State.GAME;
                        else if (command == "QUIT")
                            state = State.EXIT;
                        else
                        {
                            Console.WriteLine("Invalid command! Use 'ENTER' to start or 'QUIT' to exit.");
                            state = State.START;
                        }
                        break;

                    case State.GAME:
                        if (command == "ESC")
                            state = State.PAUSE;
                        else
                        {
                            Console.WriteLine("Playing... Press 'ESC' to pause.");
                            state = State.GAME;
                        }
                        break;

                    case State.PAUSE:
                        if (command == "BACK")
                            state = State.GAME;
                        else if (command == "HOME")
                            state = State.START;
                        else if (command == "QUIT")
                            state = State.EXIT;
                        else
                        {
                            Console.WriteLine("Invalid command! Use 'BACK' to resume, 'HOME' to start screen, or 'QUIT' to exit.");
                            state = State.PAUSE;
                        }
                        break;
                }
            }
            Console.WriteLine("EXIT SCREEN");
        }
    }
}
