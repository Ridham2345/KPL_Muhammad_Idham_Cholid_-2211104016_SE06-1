﻿using System;
using System.Text;

namespace MatematikaLibraries
{
    public class Matematika
    {
        public int FPB(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        public int KPK(int a, int b)
        {
            return (a * b) / FPB(a, b);
        }

        public string Turunan(int[] koefisien)
        {
            StringBuilder hasil = new StringBuilder();
            int derajat = koefisien.Length - 1;
            for (int i = 0; i < koefisien.Length - 1; i++)
            {
                int koef = koefisien[i];
                int turunan = koef * (derajat - i);
                if (turunan == 0) continue;

                if (hasil.Length > 0 && turunan > 0) hasil.Append(" + ");
                else if (turunan < 0) hasil.Append(" - ");

                hasil.Append(Math.Abs(turunan));
                if (derajat - i - 1 > 0)
                {
                    hasil.Append("x");
                    if (derajat - i - 1 > 1)
                        hasil.Append($"{derajat - i - 1}");
                }
            }
            return hasil.ToString();
        }

        public string Integral(int[] koefisien)
        {
            StringBuilder hasil = new StringBuilder();
            int derajat = koefisien.Length - 1;
            for (int i = 0; i < koefisien.Length; i++)
            {
                int koef = koefisien[i];
                int pangkatBaru = derajat - i + 1;
                double hasilBagi = (double)koef / pangkatBaru;

                if (hasil.Length > 0 && hasilBagi > 0) hasil.Append(" + ");
                else if (hasilBagi < 0) hasil.Append(" - ");

                hasil.Append($"{Math.Abs(hasilBagi)}x");
                if (pangkatBaru > 1) hasil.Append($"{pangkatBaru}");
            }
            hasil.Append(" + C");
            return hasil.ToString();
        }
    }
}
