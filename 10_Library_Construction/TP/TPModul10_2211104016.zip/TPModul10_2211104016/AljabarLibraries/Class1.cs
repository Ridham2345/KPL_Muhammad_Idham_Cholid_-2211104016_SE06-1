﻿using System;

namespace AljabarLibraries
{
    public class Aljabar
    {
        // Fungsi untuk mencari akar-akar dari persamaan kuadrat: ax^2 + bx + c = 0
        public static double[] AkarPersamaanKuadrat(double[] persamaan)
        {
            if (persamaan.Length != 3)
                throw new ArgumentException("Array input harus terdiri dari 3 elemen: a, b, dan c.");

            double a = persamaan[0];
            double b = persamaan[1];
            double c = persamaan[2];

            double diskriminan = b * b - 4 * a * c;

            if (diskriminan < 0)
                throw new Exception("Persamaan tidak memiliki akar real.");

            double akarDiskriminan = Math.Sqrt(diskriminan);

            double x1 = (-b + akarDiskriminan) / (2 * a);
            double x2 = (-b - akarDiskriminan) / (2 * a);

            return new double[] { x1, x2 };
        }

        // Fungsi untuk menghitung kuadrat dari bentuk (ax + b)^2
        public static double[] HasilKuadrat(double[] persamaan)
        {
            if (persamaan.Length != 2)
                throw new ArgumentException("Array input harus terdiri dari 2 elemen: a dan b.");

            double a = persamaan[0];
            double b = persamaan[1];

            double hasilA = a * a;        
            double hasilB = 2 * a * b;    
            double hasilC = b * b;        
            return new double[] { hasilA, hasilB, hasilC };
        }
    }
}
