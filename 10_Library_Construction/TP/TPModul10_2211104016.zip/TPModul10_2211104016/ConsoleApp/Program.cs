﻿using System;
using AljabarLibraries;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Memanggil fungsi untuk mencari akar dari persamaan kuadrat x^2 - 3x - 10 = 0
                double[] hasilAkar = Aljabar.AkarPersamaanKuadrat(new double[] { 1, -3, -10 });
                Console.WriteLine("Akar-akar dari x^2 - 3x - 10 = 0 adalah:");
                Console.WriteLine($"x 1 = {hasilAkar[0]}");
                Console.WriteLine($"x 2 = {hasilAkar[1]}");

                Console.WriteLine(); // baris kosong

                // Memanggil fungsi untuk mendapatkan hasil kuadrat dari (2x - 3)^2
                double[] hasilKuadrat = Aljabar.HasilKuadrat(new double[] { 2, -3 });
                Console.WriteLine("Hasil kuadrat dari (2x - 3)^2 adalah:");
                Console.WriteLine($"{hasilKuadrat[0]}x^2 + {hasilKuadrat[1]}x + {hasilKuadrat[2]}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Terjadi kesalahan: {ex.Message}");
            }

            Console.WriteLine("\nTekan sembarang tombol untuk keluar...");
            Console.ReadKey();
        }
    }
}
