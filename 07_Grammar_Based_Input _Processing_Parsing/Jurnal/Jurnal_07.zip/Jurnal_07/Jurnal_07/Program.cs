﻿using System;
using System.IO;
using System.Text.Json;

public class Program
{
    public static void ReadJSON()
    {
     
        string jsonFilePath = "jurnal7_3_2211104016.json";

        try
        {
          
            string jsonString = File.ReadAllText(jsonFilePath);

            var glossaryItem = JsonSerializer.Deserialize<GlossaryItem12345>(jsonString);

            
            GlossEntry entry = glossaryItem.Glossary.GlossDiv.GlossList.GlossEntry;

            Console.WriteLine("=== GlossEntry ===");
            Console.WriteLine($"ID: {entry.ID}");
            Console.WriteLine($"Sort As: {entry.SortAs}");
            Console.WriteLine($"Term: {entry.GlossTerm}");
            Console.WriteLine($"Acronym: {entry.Acronym}");
            Console.WriteLine($"Abbreviation: {entry.Abbrev}");
            Console.WriteLine($"Definition: {entry.GlossDef.Para}");
            Console.WriteLine($"See Also: {string.Join(", ", entry.GlossDef.GlossSeeAlso)}");
            Console.WriteLine($"Gloss See: {entry.GlossSee}");
            Console.WriteLine("==================");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error reading JSON: {ex.Message}");
        }
    }

    public static void Main(string[] args)
    {
        ReadJSON();
    }
}