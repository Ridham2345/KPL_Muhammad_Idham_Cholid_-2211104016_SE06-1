﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurnal_07
{
    class GlossaryItem2211104016
    {
    }
}
