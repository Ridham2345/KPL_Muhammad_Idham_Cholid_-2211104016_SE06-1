﻿using System.Text.Json.Serialization;

public class GlossaryItem12345
{
    [JsonPropertyName("glossary")]
    public Glossary Glossary { get; set; }
}

public class Glossary
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("GlossDiv")]
    public GlossDiv GlossDiv { get; set; }
}

public class GlossDiv
{
    [JsonPropertyName("title")]
    public string Title { get; set; }

    [JsonPropertyName("GlossList")]
    public GlossList GlossList { get; set; }
}

public class GlossList
{
    [JsonPropertyName("GlossEntry")]
    public GlossEntry GlossEntry { get; set; }
}

public class GlossEntry
{
    [JsonPropertyName("ID")]
    public string ID { get; set; }

    [JsonPropertyName("SortAs")]
    public string SortAs { get; set; }

    [JsonPropertyName("GlossTerm")]
    public string GlossTerm { get; set; }

    [JsonPropertyName("Acronym")]
    public string Acronym { get; set; }

    [JsonPropertyName("Abbrev")]
    public string Abbrev { get; set; }

    [JsonPropertyName("GlossDef")]
    public GlossDef GlossDef { get; set; }

    [JsonPropertyName("GlossSee")]
    public string GlossSee { get; set; }
}

public class GlossDef
{
    [JsonPropertyName("para")]
    public string Para { get; set; }

    [JsonPropertyName("GlossSeeAlso")]
    public string[] GlossSeeAlso { get; set; }
}