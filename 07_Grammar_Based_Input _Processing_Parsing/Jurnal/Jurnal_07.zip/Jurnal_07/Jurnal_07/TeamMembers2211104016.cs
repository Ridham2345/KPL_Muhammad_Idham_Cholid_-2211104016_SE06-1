﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;

namespace Jurnal_07
{
    public class Member
    {
        public string NIM { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
    }
    public class TeamMembers2211104016
    {
        public List<Member> Members { get; set; }

        public void ReadJSON()
        {
            try
            {
                string filePath = "jurnal7_2_2211104016.json";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine("File JSON tidak ditemukan.");
                    return;
                }

                string jsonContent = File.ReadAllText(filePath);

                TeamMembers2211104016 team = JsonConvert.DeserializeObject<TeamMembers2211104016>(jsonContent);

                if (team?.Members == null || team.Members.Count == 0)
                {
                    Console.WriteLine("Tidak ada data anggota tim.");
                    return;
                }

                Console.WriteLine("Team member list:");
                foreach (var member in team.Members)
                {
                    Console.WriteLine($"{member.NIM} {member.FirstName} {member.LastName} ({member.Age} {member.Gender})");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading JSON: {ex.Message}");
            }
        }
    }
}
