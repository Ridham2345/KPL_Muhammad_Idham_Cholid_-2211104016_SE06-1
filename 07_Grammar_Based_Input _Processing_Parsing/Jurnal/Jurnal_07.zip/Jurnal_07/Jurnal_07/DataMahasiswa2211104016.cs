﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurnal_07
{
    public class Address
    {
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
    }

    public class Course
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class DataMahasiswa2211104016
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public Address Address { get; set; }
        public List<Course> Courses { get; set; }

        public static void ReadJSON()
        {
            try
            {
            
                string filePath = "jurnal7_1_2211104016.json"; 
                

                string jsonData = File.ReadAllText(filePath);
                DataMahasiswa2211104016 mahasiswa = JsonConvert.DeserializeObject<DataMahasiswa2211104016>(jsonData);

                
                Console.WriteLine("===== Data Mahasiswa =====");
                Console.WriteLine($"Nama: {mahasiswa.FirstName} {mahasiswa.LastName}");
                Console.WriteLine($"Jenis Kelamin: {mahasiswa.Gender}");
                Console.WriteLine($"Umur: {mahasiswa.Age}");
                Console.WriteLine($"Alamat: {mahasiswa.Address.StreetAddress}, {mahasiswa.Address.City}, {mahasiswa.Address.State}");
                Console.WriteLine("\nMata Kuliah:");
                foreach (var course in mahasiswa.Courses)
                {
                    Console.WriteLine($"- {course.Code}: {course.Name}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error saat membaca JSON: " + ex.Message);
            }
        }
    }
}
