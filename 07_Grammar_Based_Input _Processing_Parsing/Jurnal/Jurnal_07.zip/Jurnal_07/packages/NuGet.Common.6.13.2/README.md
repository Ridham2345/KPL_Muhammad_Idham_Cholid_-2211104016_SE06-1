Common utilities and interfaces for all NuGet libraries.
