NuGet's implementation of Semantic Versioning.
