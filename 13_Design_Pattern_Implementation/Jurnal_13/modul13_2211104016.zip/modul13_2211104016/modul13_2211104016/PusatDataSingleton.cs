﻿using System;
using System.Collections.Generic;

namespace modul13_2211104016
{
    public class PusatDataSingleton
    {
        private static readonly Lazy<PusatDataSingleton> _instance =
            new Lazy<PusatDataSingleton>(() => new PusatDataSingleton());

        public static PusatDataSingleton Instance => _instance.Value;

        private List<string> DataTersimpan;

        private PusatDataSingleton()
        {
            DataTersimpan = new List<string>();
        }

        public List<string> GetSemuaData()
        {
            return DataTersimpan;
        }

        public void PrintSemuaData()
        {
            foreach (string data in DataTersimpan)
            {
                Console.WriteLine(data);
            }
        }

        public void AddSebuahData(string input)
        {
            DataTersimpan.Add(input);
        }

        public void HapusSebuahData(int index)
        {
            if (index >= 0 && index < DataTersimpan.Count)
            {
                DataTersimpan.RemoveAt(index);
            }
        }
    }
}