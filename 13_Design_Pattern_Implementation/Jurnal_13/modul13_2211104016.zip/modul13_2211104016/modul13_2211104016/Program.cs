﻿using modul13_2211104016;
using System;

class Program
{
    static void Main(string[] args)
    {
        var data1 = PusatDataSingleton.Instance;
        var data2 = PusatDataSingleton.Instance;

        data1.AddSebuahData("Idham Cholid");
        data1.AddSebuahData("Maulana Stalin");
        data1.AddSebuahData("Maulana Habibrhoman");
        data1.AddSebuahData("abdul aziz");
        data1.AddSebuahData("Asisten Praktikum");

        Console.WriteLine("Print Dari Data:");
        data2.PrintSemuaData();

        data2.HapusSebuahData(3);

        Console.WriteLine("\nMenghapus data2 Astisten Praktikumn:");
        data1.PrintSemuaData();

        Console.WriteLine("\nPrint dari data 1 setelah menghapus");

        Console.WriteLine($"\nJumlah data di data1: {data1.GetSemuaData().Count}");
        Console.WriteLine($"Jumlah data di data2: {data2.GetSemuaData().Count}");

        Console.ReadLine(); 
    }
}
