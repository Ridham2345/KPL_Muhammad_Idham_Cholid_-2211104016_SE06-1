﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TpModul5_2211104016
{
    public class HaloGeneric<T>
    {
        public void SapaUser(T user)
        {
            Console.WriteLine($"Halo user {user}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            HaloGeneric<string> halo = new HaloGeneric<string>();
            halo.SapaUser("Muhammmad Idham Cholid");
        }
    }
}
